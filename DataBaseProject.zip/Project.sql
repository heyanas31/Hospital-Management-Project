CREATE DATABASE HOSPITAL;

USE HOSPITAL;

-- DROP DATABASE HOSPITAL;
                                          /*MAKING TABLES*/
CREATE TABLE PATIENT
(
PATIENT_ID INT(5),
FNAME VARCHAR(15),
LNAME VARCHAR(15),
DOB DATE,
GENDER CHAR(7),
CNIC VARCHAR (15) UNIQUE NOT NULL,
PATIENT_PHONE INT(15),
PATIENT_EMAIL VARCHAR(35) DEFAULT NULL,
ADDRESS VARCHAR(30),
BLOOD_GROUP VARCHAR(3),
DOSE_INFO VARCHAR(20),
APP_ID INT(5),
BILL_ID INT(5)
);

CREATE TABLE APPOINTMENT
(
APPOINTMENT_ID INT(5),
APP_TIME time not null,
APP_DATE DATE not null,
APPOINTMENT_TYPE VARCHAR(30),
DOCTOR_ID INT(5)
);

CREATE TABLE BILL
(
BILL_ID INT(5)PRIMARY KEY,
AMOUNT VARCHAR(15),
ISSUE_DATE DATE,
CASH_PAYMENT VARCHAR(3) DEFAULT "NO",
CARD_PAYMENT VARCHAR(3) DEFAULT "NO",
DUE_DATE DATE
);

CREATE TABLE DOCTOR
(
DOCTOR_ID INT(5),
FNAME VARCHAR(15),
LNAME VARCHAR(15),
GENDER CHAR(2),
DOC_PHONE INT(20),
DOC_EMAIL VARCHAR(35) DEFAULT NULL,
DOJ DATE,
EXPERIENCE INT(3),
SALARY INT(10),
SPECIALIZATION VARCHAR(30),
DEP_ID INT(5)
);

CREATE TABLE REPORT
(
REPORT_ID INT(5),
ISSUE_DATE DATE,
REPORT_RESULT VARCHAR(20), 
DOCTOR_ID INT(5),
PATIENT_ID INT(5)
);

CREATE TABLE DEPARTMENT
(
DEPARTMENT_ID INT(5),
DEP_NAME VARCHAR(40),
HOD_FNAME VARCHAR(40),
HOD_LNAME VARCHAR(45),
LOCATION VARCHAR(70),
CITY VARCHAR(40)
);

CREATE TABLE STAFF
(
STAFF_ID INT(5),
FNAME VARCHAR(15),
LNAME VARCHAR(15),
GENDER VARCHAR(7),
DESIGNATION VARCHAR(15),
SALARY INT(15),
STAFF_PHONE INT(11),
STAFF_EMAIL VARCHAR(35) DEFAULT NULL,
STAFF_TYPE VARCHAR(25) NOT NULL
);

CREATE TABLE WORKS_IN
(
DEP_ID INT(5),
STAFF_ID INT(5),
HOURS INT(3)
);
                                                /*SETTING PRIMARY AND FOREIGN KEYS*/
SET SQL_SAFE_UPDATES = 0;

ALTER TABLE PATIENT ADD PRIMARY KEY(PATIENT_ID);
ALTER TABLE PATIENT ADD constraint FK1 foreign key(APP_ID) references APPOINTMENT(APPOINTMENT_ID);
ALTER TABLE PATIENT ADD constraint FK2 foreign key(BILL_ID) references BILL(BILL_ID);

ALTER TABLE APPOINTMENT ADD PRIMARY KEY (APPOINTMENT_ID); 
ALTER TABLE APPOINTMENT ADD constraint FK3 foreign key(DOCTOR_ID) references DOCTOR(DOCTOR_ID);

ALTER TABLE DOCTOR ADD PRIMARY KEY (DOCTOR_ID);
ALTER TABLE DOCTOR ADD constraint FK4 foreign key(DEP_ID)references DEPARTMENT (DEPARTMENT_ID);

ALTER TABLE REPORT ADD primary key(REPORT_ID);
ALTER TABLE REPORT ADD constraint fk5 foreign key (DOCTOR_ID)references DOCTOR(DOCTOR_ID);
ALTER TABLE REPORT ADD constraint fk6 foreign key (PATIENT_ID)references PATIENT(PATIENT_ID);

ALTER TABLE DEPARTMENT ADD PRIMARY KEY(DEPARTMENT_ID);

ALTER TABLE STAFF ADD primary key(STAFF_ID);

ALTER TABLE WORKS_IN ADD constraint FK7 foreign key(DEP_ID) references DEPARTMENT (DEPARTMENT_ID);
ALTER TABLE WORKS_IN ADD constraint FK8 foreign key(STAFF_ID)references STAFF (STAFF_ID);

                                                 /*INSERTING DATA*/
                                         
INSERT INTO PATIENT (PATIENT_ID, FNAME, LNAME, DOB, GENDER, CNIC, PATIENT_PHONE, PATIENT_EMAIL, ADDRESS, BLOOD_GROUP, DOSE_INFO, APP_ID, BILL_ID)
VALUES (101, 'Ali', 'Khan', '1985-07-20', 'Male', '35202-1234567-1', 30123456, 'ali.khan@gmail.com', 'House 123, G-10/4, Islamabad', 'B+', 'Dose1', 1, 1),
       (102, 'Sara', 'Ahmed', '1992-05-15', 'Female', '35202-2345678-2', 30256789, 'sara.ahmed@yahoo.com', 'House 456, DHA Phase 5, Lahore', 'O-', 'Dose2', 2, 2),
       (103, 'Faisal', 'Hussain', '1978-03-10', 'Male', '35202-3456789-3', 34567890, 'faisal.hussain@outlook.com', 'House 789, Clifton, Karachi', 'A+', 'Dose1', 3, 3),
       (104, 'Ayesha', 'Malik', '1990-04-12', 'Female', '35202-4567890-4', 45678901, 'ayesha.malik@gmail.com', 'House 321, F-8/3, Islamabad', 'AB-', 'Dose 2', 4, 4),
       (105, 'Usman', 'Tariq', '1983-11-05', 'Male', '35202-5678901-5', 30589012, 'usman.tariq@yahoo.com', 'House 654, Gulshan, Karachi', 'B-', 'Dose 1', 5, 5),
       (106, 'Nadia', 'Saeed', '1975-08-20', 'Female', '35202-6789012-6', 37890123, 'nadia.saeed@outlook.com', 'House 987, Model Town, Lahore', 'O+', 'Dose 2', 6, 6),
       (107, 'Bilal', 'Khan', '1988-03-22', 'Male', '35202-7890123-7', 30701234, 'bilal.khan@gmail.com', 'House 111, DHA Phase 6, Lahore', 'A-', 'Dose 1', 7, 7),
       (108, 'Farah', 'Zahid', '1993-09-15', 'Female', '35202-8901234-8', 30012345, 'farah.zahid@yahoo.com', 'House 222, I-8/2, Islamabad', 'B+', 'Dose 2', 8, 8),
       (109, 'Zain', 'Ali', '1977-12-30', 'Male', '35202-9012345-9', 30901456, 'zain.ali@outlook.com', 'House 333, Gulberg, Lahore', 'AB+', 'Dose 1', 9, 9),
       (110, 'Hira', 'Qureshi', '1995-02-18', 'Female', '35202-0123456-0', 31234567, 'hira.qureshi@gmail.com', 'House 444, PECHS, Karachi', 'A+', 'Dose 2', 10, 10),
       (111, 'Omar', 'Shah', '1981-06-25', 'Male', '35202-2345670-1', 30125670, 'omar.shah@yahoo.com', 'House 555, F-7/1, Islamabad', 'O-', 'Dose 1', 11, 11),
       (112, 'Sana', 'Latif', '1994-11-09', 'Female', '35202-3456780-2', 30456780, 'sana.latif@outlook.com', 'House 666, Bahria Town, Lahore', 'B-', 'Dose 2', 12, 12),
       (113, 'Hamza', 'Yousaf', '1989-01-14', 'Male', '35202-4567890-3', 30567890, 'hamza.yousaf@gmail.com', 'House 777, Clifton, Karachi', 'AB-', 'Dose 1', 13, 13),
       (114, 'Fatima', 'Zafar', '1991-07-21', 'Female', '35202-5678900-4', 30678900, 'fatima.zafar@yahoo.com', 'House 888, G-9/1, Islamabad', 'O+', 'Dose 2', 14, 14),
       (115, 'Arsalan', 'Mehmood', '1986-05-11', 'Male', '35202-6789010-5', 30589010, 'arsalan.mehmood@outlook.com', 'House 999, DHA Phase 2, Lahore', 'A-', 'Dose 1', 15, 15);

INSERT INTO APPOINTMENT (APPOINTMENT_ID, APP_TIME, APP_DATE, APPOINTMENT_TYPE, DOCTOR_ID)
VALUES (1, '10:00:00', '2023-06-15', 'General Checkup', 201),
       (2, '11:30:00', '2023-06-16', 'Dental Checkup', 202),
       (3, '09:00:00', '2023-06-17', 'Eye Checkup', 203),
       (4, '14:00:00', '2023-06-18', 'Cardiology Consultation', 204),
       (5, '15:30:00', '2023-06-19', 'Dermatology Consultation', 205),
       (6, '13:00:00', '2023-06-20', 'Neurology Consultation', 206),
       (7, '16:00:00', '2023-06-21', 'Orthopedic Consultation', 207),
       (8, '08:00:00', '2023-06-22', 'Pediatrics Consultation', 208),
       (9, '11:00:00', '2023-06-23', 'Psychiatry Consultation', 209),
       (10, '10:30:00', '2023-06-24', 'Gynecology Consultation', 210),
       (11, '12:30:00', '2023-06-25', 'Urology Consultation', 211),
       (12, '09:30:00', '2023-06-26', 'Oncology Consultation', 212),
       (13, '13:30:00', '2023-06-27', 'Endocrinology Consultation', 213),
       (14, '14:30:00', '2023-06-28', 'Hematology Consultation', 214),
       (15, '15:00:00', '2023-06-29', 'Rheumatology Consultation', 215);

INSERT INTO BILL (BILL_ID, AMOUNT, ISSUE_DATE, CASH_PAYMENT, CARD_PAYMENT, DUE_DATE)
VALUES (1, '5000', '2023-06-20', 'YES', 'NO', '2023-07-01'),
       (2, '2000', '2023-06-21', 'NO', 'YES', '2023-07-02'),
       (3, '3000', '2023-06-22', 'YES', 'NO', '2023-07-03'),
       (4, '1500', '2023-06-23', 'NO', 'YES', '2023-07-04'),
       (5, '4000', '2023-06-24', 'YES', 'NO', '2023-07-05'),
       (6, '2500', '2023-06-25', 'NO', 'YES', '2023-07-06'),
       (7, '3500', '2023-06-26', 'YES', 'NO', '2023-07-07'),
       (8, '4500', '2023-06-27', 'NO', 'YES', '2023-07-08'),
       (9, '1000', '2023-06-28', 'YES', 'NO', '2023-07-09'),
       (10, '2000', '2023-06-29', 'NO', 'YES', '2023-07-10'),
       (11, '3000', '2023-06-30', 'YES', 'NO', '2023-07-11'),
       (12, '4000', '2023-07-01', 'NO', 'YES', '2023-07-12'),
       (13, '5000', '2023-07-02', 'YES', 'NO', '2023-07-13'),
       (14, '6000', '2023-07-03', 'NO', 'YES', '2023-07-14'),
       (15, '7000', '2023-07-04', 'YES', 'NO', '2023-07-15');

INSERT INTO DOCTOR (DOCTOR_ID, FNAME, LNAME, GENDER, DOC_PHONE, DOC_EMAIL, DOJ, EXPERIENCE, SALARY, SPECIALIZATION, DEP_ID)
VALUES (201, 'Asim', 'Raza', 'M', 30145678, 'asim.raza@gmail.com', '2010-01-10', 14, 200000, 'Cardiologist', 1),
       (202, 'Nadia', 'Kamal', 'F', 30256789, 'nadia.kamal@yahoo.com', '2012-03-20', 12, 180000, 'Dentist', 2),
       (203, 'Usman', 'Iqbal', 'M', 30347890, 'usman.iqbal@outlook.com', '2015-05-30', 9, 150000, 'Ophthalmologist', 3),
       (204, 'Ayesha', 'Rafiq', 'F', 30478901, 'ayesha.rafiq@gmail.com', '2009-04-15', 15, 220000, 'Neurologist', 4),
       (205, 'Bilal', 'Saeed', 'M', 30569012, 'bilal.saeed@yahoo.com', '2011-07-20', 13, 190000, 'Orthopedic', 5),
       (206, 'Farah', 'Naeem', 'F', 30890123, 'farah.naeem@outlook.com', '2014-09-25', 10, 160000, 'Dermatologist', 6),
       (207, 'Zain', 'Ali', 'M', 30789234, 'zain.ali@gmail.com', '2013-11-30', 11, 170000, 'Pediatrician', 7),
       (208, 'Omar', 'Shahid', 'M', 30890145, 'omar.shahid@yahoo.com', '2010-02-10', 14, 180000, 'Psychiatrist', 8),
       (209, 'Sana', 'Latif', 'F', 30901456, 'sana.latif@outlook.com', '2016-05-15', 8, 140000, 'Gynecologist', 9),
       (210, 'Hamza', 'Yousaf', 'M', 30012347, 'hamza.yousaf@gmail.com', '2008-07-20', 16, 230000, 'Urologist', 10),
       (211, 'Fatima', 'Zafar', 'F', 30123450, 'fatima.zafar@yahoo.com', '2012-10-25', 12, 175000, 'Oncologist', 11),
       (212, 'Arsalan', 'Mehmood', 'M', 33456780, 'arsalan.mehmood@outlook.com', '2015-01-30', 9, 150000, 'Endocrinologist', 12),
       (213, 'Ali', 'Raza', 'M', 30345678, 'ali.raza@gmail.com', '2011-04-10', 13, 190000, 'Hematologist', 13),
       (214, 'Zara', 'Sheikh', 'F', 30456789, 'zara.sheikh@yahoo.com', '2013-06-15', 11, 170000, 'Rheumatologist', 14),
       (215, 'Bilal', 'Khan', 'M', 3789010, 'bilal.khan@outlook.com', '2009-08-20', 15, 220000, 'Pulmonologist', 15);

INSERT INTO REPORT (REPORT_ID, ISSUE_DATE, REPORT_RESULT, DOCTOR_ID, PATIENT_ID)
VALUES (1, '2023-06-23', 'Normal', 201, 101),
       (2, '2023-06-24', 'Cavity Detected', 202, 102),
       (3, '2023-06-25', 'Vision Impaired', 203, 103),
       (4, '2023-06-26', 'Migraine', 204, 104),
       (5, '2023-06-27', 'Fracture', 205, 105),
       (6, '2023-06-28', 'Dermatitis', 206, 106),
       (7, '2023-06-29', 'Flu', 207, 107),
       (8, '2023-06-30', 'Anxiety', 208, 108),
       (9, '2023-07-01', 'Pregnancy', 209, 109),
       (10, '2023-07-02', 'Kidney Stone', 210, 110),
       (11, '2023-07-03', 'Cancer', 211, 111),
       (12, '2023-07-04', 'Diabetes', 212, 112),
       (13, '2023-07-05', 'Anemia', 213, 113),
       (14, '2023-07-06', 'Arthritis', 214, 114),
       (15, '2023-07-07', 'Asthma', 215, 115);

INSERT INTO DEPARTMENT (DEPARTMENT_ID, DEP_NAME, HOD_FNAME, HOD_LNAME, LOCATION,CITY)
VALUES (1, 'Cardiology', 'Asim', 'Raza', 'PIMS','Islamabad'),
       (2, 'Dentistry', 'Nadia', 'Kamal', 'Jinnah Hospital','Lahore'),
       (3, 'Ophthalmology', 'Usman', 'Iqbal', 'Aga Khan Hospital', 'Karachi'),
       (4, 'Neurology', 'Ayesha','Rafiq', 'Shifa Hospital', 'Islamabad'),
       (5, 'Orthopedics', 'Bilal' ,'Saeed', 'CMH', 'Lahore'),
       (6, 'Dermatology', 'Farah', 'Naeem', 'Services Hospital', 'Lahore'),
       (7, 'Pediatrics', 'Zain', 'Ali', 'Holy Family Hospital', 'Rawalpindi'),
       (8, 'Psychiatry', 'Omar', 'Shahid', 'Mayo Hospital', 'Lahore'),
       (9, 'Gynecology', 'Sana', 'Latif', 'Lady Hospital', 'Peshawar'),
       (10, 'Urology', 'Hamza', 'Yousaf', 'Zayed Hospital', 'Lahore'),
       (11, 'Oncology', 'Fatima', 'Zafar', 'Shaukat Khanum Hospital', 'Lahore'),
       (12, 'Endocrinology', 'Arsalan', 'Mehmood', 'National Hospital', 'Karachi'),
       (13, 'Hematology', 'Ali', 'Raza', 'Shifa Hospital', 'Karachi'),
       (14, 'Rheumatology', 'Zara' ,'Sheikh', 'JPMC', 'Karachi'),
       (15, 'Pulmonology', 'Bilal','Khan', 'Indus Hospital', 'Karachi');

INSERT INTO STAFF (STAFF_ID, FNAME, LNAME, GENDER, DESIGNATION, SALARY, STAFF_PHONE, STAFF_EMAIL, STAFF_TYPE)
VALUES (301, 'Ahmed', 'Ali', 'Male', 'Nurse', 50000, 30125678, 'ahmed.ali@gmail.com', 'Full-Time'),
       (302, 'Zara', 'Sheikh', 'Female', 'Technician', 40000, 30256789, 'zara.sheikh@yahoo.com', 'Part-Time'),
       (303, 'Bilal', 'Khan', 'Male', 'Receptionist', 30000, 30347890, 'bilal.khan@outlook.com', 'Contract'),
       (304, 'Farah', 'Naeem', 'Female', 'Nurse', 50000, 30456901, 'farah.naeem@gmail.com', 'Full-Time'),
       (305, 'Usman', 'Tariq', 'Male', 'Technician', 40000, 30589012, 'usman.tariq@yahoo.com', 'Part-Time'),
       (306, 'Sara', 'Ahmed', 'Female', 'Receptionist', 30000, 30890123, 'sara.ahmed@outlook.com', 'Contract'),
       (307, 'Hassan', 'Shah', 'Male', 'Nurse', 50000, 30789014, 'hassan.shah@gmail.com', 'Full-Time'),
       (308, 'Ayesha', 'Khan', 'Female', 'Technician', 40000, 30812345, 'ayesha.khan@yahoo.com', 'Part-Time'),
       (309, 'Faisal', 'Hussain', 'Male', 'Receptionist', 30000, 30923456, 'faisal.hussain@outlook.com', 'Contract'),
       (310, 'Nadia', 'Saeed', 'Female', 'Nurse', 50000, 30012347, 'nadia.saeed@gmail.com', 'Full-Time'),
       (311, 'Omar', 'Latif', 'Male', 'Technician', 40000, 30123670, 'omar.latif@yahoo.com', 'Part-Time'),
       (312, 'Sana', 'Raza', 'Female', 'Receptionist', 30000, 30456780, 'sana.raza@outlook.com', 'Contract'),
       (313, 'Hamza', 'Iqbal', 'Male', 'Nurse', 50000, 30345690, 'hamza.iqbal@gmail.com', 'Full-Time'),
       (314, 'Fatima', 'Qureshi', 'Female', 'Technician', 40000, 30478900, 'fatima.qureshi@yahoo.com', 'Part-Time'),
       (315, 'Arsalan', 'Mehmood', 'Male', 'Receptionist', 30000, 30789010, 'arsalan.mehmood@outlook.com', 'Contract');

INSERT INTO WORKS_IN (DEP_ID, STAFF_ID, HOURS)
VALUES (1, 301, 40),
       (2, 302, 20),
       (3, 303, 30),
       (4, 304, 40),
       (5, 305, 20),
       (6, 306, 30),
       (7, 307, 40),
       (8, 308, 20),
       (9, 309, 30),
       (10, 310, 40),
       (11, 311, 20),
       (12, 312, 30),
       (13, 313, 40),
       (14, 314, 20),
       (15, 315, 30);
 
                              /*SELECT TO SHOW ALL DATA*/
SELECT * FROM PATIENT;
SELECT * FROM DEPARTMENT;
SELECT * FROM APPOINTMENT;
SELECT * FROM DOCTOR;
SELECT * FROM STAFF;
SELECT * FROM BILL;
SELECT * FROM WORKS_IN;
                             /*ALTER AND UPDATE QUERIES*/
                             
ALTER TABLE PATIENT MODIFY ADDRESS VARCHAR(35);
DELETE FROM WORKS_IN WHERE DEP_ID = 15;
UPDATE WORKS_IN SET HOURS = 15 WHERE DEP_ID = 15;    
UPDATE STAFF SET STAFF_TYPE = 'Contract' WHERE STAFF_ID = 310;  
DELETE FROM WORKS_IN WHERE STAFF_ID = 315;                      
                             
                               /*AGGREGATE FUNCTIONS*/
                             
SELECT AVG(SALARY) FROM STAFF;  
SELECT SUM(SALARY) FROM DOCTOR;  
SELECT COUNT(SALARY) FROM STAFF;  
SELECT MAX(SALARY) FROM DOCTOR;  
SELECT MIN(SALARY) as minimum FROM STAFF;                                  
                             
						       /*JOIN QURIES*/

-- Question : List all patients along with their appointment details.
SELECT P.PATIENT_ID, P.FNAME, P.LNAME, A.APP_DATE, A.APP_TIME, A.APPOINTMENT_TYPE 
FROM PATIENT as P
JOIN APPOINTMENT as A ON P.APP_ID = A.APPOINTMENT_ID;

-- Question : Find all appointments scheduled with a specific doctor.
SELECT A.APPOINTMENT_ID, A.APP_DATE, A.APP_TIME, P.FNAME, P.LNAME
FROM APPOINTMENT as A
JOIN DOCTOR as D ON A.DOCTOR_ID = D.DOCTOR_ID
JOIN PATIENT as P ON A.APPOINTMENT_ID = P.APP_ID
WHERE D.FNAME = 'Asim' AND D.LNAME = 'Raza';

-- Question : Show the data of the staff memebers who work in the department located in Lahore.
SELECT S.*, D.CITY
FROM STAFF AS S 
JOIN WORKS_IN as W on S.STAFF_ID = W.STAFF_ID 
JOIN DEPARTMENT AS D ON W.DEP_ID=D.DEPARTMENT_ID where D.CITY like 'LAHORE';

-- Question : List all departments along with the number of staff members working in each department.
SELECT D.DEP_NAME, COUNT(s.STAFF_ID) AS STAFF_COUNT
FROM DEPARTMENT as D
JOIN WORKS_IN AS W ON D.DEPARTMENT_ID = W.DEP_ID
JOIN STAFF AS S ON W.STAFF_ID = S.STAFF_ID
GROUP BY D.DEP_NAME;

-- Question : list of patients along with their reports and the doctors who generated those reports.
SELECT P.PATIENT_ID, P.FNAME, P.LNAME, R.REPORT_ID, R.REPORT_RESULT, D.FNAME AS DOCTOR_FNAME, D.LNAME AS DOCTOR_LNAME
FROM PATIENT as P
JOIN REPORT as R ON P.PATIENT_ID = R.PATIENT_ID
JOIN DOCTOR as D ON R.DOCTOR_ID = D.DOCTOR_ID;

-- Question : Find the names of patients along with their billing amount greater then 4k and payment status.
SELECT P.PATIENT_ID, P.FNAME, P.LNAME, B.AMOUNT, B.CASH_PAYMENT, B.CARD_PAYMENT
FROM PATIENT AS P
JOIN BILL AS B ON P.BILL_ID = B.BILL_ID where B.AMOUNT > 4000;

-- Question : Retrieve the billing details of all patients who have paid via card.
SELECT p.PATIENT_ID, p.FNAME, p.LNAME, p.CNIC, b.AMOUNT, b.ISSUE_DATE
FROM PATIENT p
JOIN BILL b ON p.BILL_ID = b.BILL_ID
WHERE b.CARD_PAYMENT = 'YES';

-- Question : Show the patiient that has paid the maximun bill.
SELECT P.PATIENT_ID,P.FNAME,P.LNAME,max(B.AMOUNT)
FROM PATIENT AS P 
JOIN BILL AS B ON P.BILL_ID = B.BILL_ID where B.AMOUNT = max(B.AMOUNT);

-- Question : Retrieve the names and specialization of doctors who have treated patients with blood group 'A+'
SELECT d.DOCTOR_ID, d.FNAME, d.LNAME, d.SPECIALIZATION
FROM DOCTOR d
JOIN APPOINTMENT a ON d.DOCTOR_ID = a.DOCTOR_ID
JOIN PATIENT p ON a.APPOINTMENT_ID = p.APP_ID
WHERE p.BLOOD_GROUP = 'A+';

-- Question : Count the number of Male patient  in Hospital
SELECT count(P.PATIENT_ID) as MALEPatient,count(D.DOCTOR_ID) as MALEdoctor
from PATIENT AS P 
join APPOINTMENT AS A 
on P.APP_ID =A.APPOINTMENT_ID
join DOCTOR AS D ON D.DOCTOR_ID= A.DOCTOR_ID where P.GENDER like 'Male';

                        /*Nested Queries*/
                        
-- Question : Find the paitien who has paid the maximun bill
SELECT p.PATIENT_ID, p.FNAME, p.LNAME, b.AMOUNT
FROM PATIENT p
JOIN BILL b ON p.BILL_ID = b.BILL_ID
WHERE b.AMOUNT = (
SELECT MAX(AMOUNT)
FROM BILL
);

-- Question : List all doctors who have experience greater than the average experience of all doctors.
SELECT DOCTOR_ID, FNAME, LNAME, EXPERIENCE
FROM DOCTOR
WHERE EXPERIENCE > (
SELECT AVG(EXPERIENCE)
FROM DOCTOR
);

-- Question : Porvide the names of patients with the total number of appointments they have scheduled
SELECT FNAME, LNAME, (
SELECT COUNT(*)
FROM APPOINTMENT
WHERE PATIENT_ID = p.PATIENT_ID
) AS NUM_APPOINTMENTS
FROM PATIENT p;

-- Question : List all doctors who have not scheduled any appointments
SELECT DOCTOR_ID, FNAME, LNAME
FROM DOCTOR
WHERE DOCTOR_ID NOT IN (
SELECT DOCTOR_ID
FROM APPOINTMENT
);

-- Question : Show the names of patients who have appointments scheduled with the doctor who has the highest salary.
SELECT FNAME, LNAME
FROM PATIENT
WHERE APP_ID IN (
SELECT APPOINTMENT_ID
FROM APPOINTMENT
WHERE DOCTOR_ID = (
SELECT DOCTOR_ID
FROM DOCTOR
ORDER BY SALARY DESC LIMIT 1)
);

-- Question : Find all doctors who have issued reports for patients with blood group 'O-'
SELECT DOCTOR_ID, FNAME, LNAME
FROM DOCTOR
WHERE DOCTOR_ID IN (
SELECT DOCTOR_ID
FROM REPORT
WHERE PATIENT_ID IN (
SELECT PATIENT_ID
FROM PATIENT
WHERE BLOOD_GROUP = 'O-') 
);

-- Question : show staff members who work in departments 7 and have salary 50000.
SELECT STAFF_ID, FNAME, LNAME
FROM STAFF
WHERE STAFF_ID IN 
(
SELECT STAFF_ID FROM WORKS_IN where DEP_ID = 7) and SALARY = 50000;

-- Question: Show the third highest salary of staff
SELECT MIN(SALARY)
FROM STAFF 
WHERE SALARY not in 
(select MIN(salary) from STAFF WHERE SALARY not in 
(select MIN(salary) from STAFF)); 

-- Question : show all patients who have appointments scheduled with doctors who joined the hospital before the year 2015
SELECT PATIENT_ID, FNAME, LNAME
FROM PATIENT
WHERE APP_ID IN 
(SELECT APPOINTMENT_ID
FROM APPOINTMENT
WHERE DOCTOR_ID IN 
(SELECT DOCTOR_ID
FROM DOCTOR
WHERE DOJ < '2015-01-01'));


-- Question : List all patients who have not any appointments.
SELECT FNAME, LNAME
FROM PATIENT
WHERE PATIENT_ID NOT IN (
SELECT PATIENT_ID
FROM APPOINTMENT
);

                         /*Co-Related Quries*/
                         
-- Question : List patients who have appointments with a specific doctor.
SELECT FNAME, LNAME
FROM PATIENT
WHERE APP_ID IN (SELECT APPOINTMENT_ID FROM APPOINTMENT WHERE DOCTOR_ID between 201 and 204 );

-- Question : Check if a Doctor Exists for a Specific Specialization
SELECT DOCTOR_ID, FNAME, LNAME
FROM DOCTOR as D
WHERE EXISTS (
 SELECT *
FROM DEPARTMENT as DEP
WHERE D.DEP_ID = DEP.DEPARTMENT_ID
AND DEP.DEP_NAME = 'Cardiology');

-- Question : List Doctors Who Are Assigned to a Department Located in a Specific City
SELECT DOCTOR_ID, FNAME, LNAME
FROM DOCTOR as D
WHERE EXISTS (
SELECT *
FROM DEPARTMENT as DEP
WHERE D.DEP_ID = DEP.DEPARTMENT_ID
AND DEP.CITY = 'Lahore');

-- Question : Show all doctors who have issued at least one report.
SELECT D.DOCTOR_ID, D.FNAME, D.LNAME
FROM DOCTOR D
WHERE EXISTS 
(SELECT *
FROM REPORT as R WHERE R.DOCTOR_ID = D.DOCTOR_ID);

-- Question : Select all departments that have at least one staff member working more than 30 hours
SELECT DEP.DEPARTMENT_ID, DEP.DEP_NAME
FROM DEPARTMENT as DEP
WHERE EXISTS
(SELECT * FROM WORKS_IN as W 
WHERE W.DEP_ID = DEP.DEPARTMENT_ID AND W.HOURS > 30);

                                             /*CREATING VIEW*/
                                             
CREATE VIEW DOC_DATA as 
SELECT DOCTOR_ID, FNAME, LNAME, DOC_PHONE, DOC_EMAIL, EXPERIENCE, SALARY, SPECIALIZATION FROM DOCTOR 
WHERE  EXPERIENCE >=10;       

CREATE VIEW PATIENT_DATA as 
SELECT PATIENT_ID, FNAME, LNAME, DOB, CNIC, PATIENT_PHONE, PATIENT_EMAIL, ADDRESS, BLOOD_GROUP FROM PATIENT
WHERE   PATIENT_EMAIL like '%@gmail%';

CREATE VIEW STAFF_VIEW as 
SELECT STAFF_ID, FNAME, LNAME, DESIGNATION, SALARY,STAFF_TYPE FROM STAFF
WHERE DESIGNATION LIKE 'Nurse';      

CREATE VIEW DEPARTMENT_VIEW as 
SELECT DEPARTMENT_ID, DEP_NAME, HOD_FNAME,CITY FROM DEPARTMENT
WHERE CITY LIKE 'ISLAMABAD';  

                                             /*SHOW VIEW*/
SELECT * FROM DOC_DATA; 
SELECT * FROM PATIENT_DATA;  
SELECT * FROM STAFF_VIEW;
SELECT * FROM DEPARTMENT_VIEW;
                                            /*THE END*/